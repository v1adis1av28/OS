#include "Savedata.h"

Cars::Cars()
    {
        Model = "";
        quantity = 1;
        price = 20000;
        volume = 1;
        Capacity = 2;
        Carrying = 2;
        Acceleration = 5;
        MaxSpeed = 60;
        Climat = false;
        Passenger = false;
        Truck = false;
        Trailer = false;
        Bus = false;
    };
