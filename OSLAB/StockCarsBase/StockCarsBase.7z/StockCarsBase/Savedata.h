#ifndef SAVEDATA_H
#define SAVEDATA_H
#include<QString>
#include<QDate>


class Cars
{
public:
    Cars();
    QString Model;
    int id;
    int quantity;
    int price;
    double volume;
    int Capacity;
    int Carrying;
    int Acceleration;
    int MaxSpeed;
    bool Climat;
    bool Passenger;
    bool Truck;
    bool Trailer;
    bool Bus;
    QDate date;
    struct CarData {
        char Model[100];    // Модель автомобиля
        int id;             // ID
        int quantity;       // Количество
        int price;          // Цена
        double volume;      // Объем
        int Capacity;       // Вместимость
        int Carrying;       // Грузоподъемность
        int Acceleration;   // Ускорение
        int MaxSpeed;       // Максимальная скорость
        bool Climat;        // Климат-контроль
        bool Passenger;     // Пассажирский
        bool Truck;         // Грузовик
        bool Trailer;       // Прицеп
        bool Bus;           // Автобус
        char date[20];      // Дата
    };
    static CarData toCarData(Cars &car) {
        CarData data;
        QByteArray stringData;

        // Модель автомобиля
        stringData = car.Model.toUtf8();
        std::copy(stringData.constBegin(), stringData.constBegin() + qMin(99, stringData.size()), data.Model);
        data.Model[qMin(100, stringData.size())] = '\0';
        data.id = car.id;
        data.quantity = car.quantity;
        data.price = car.price;
        data.volume = car.volume;
        data.Capacity = car.Capacity;
        data.Carrying = car.Carrying;
        data.Acceleration = car.Acceleration;
        data.MaxSpeed = car.MaxSpeed;
        data.Climat = car.Climat;
        data.Passenger = car.Passenger;
        data.Truck = car.Truck;
        data.Trailer = car.Trailer;
        data.Bus = car.Bus;
        stringData = car.date.toString("dd.MM.yyyy").toUtf8();
        std::copy(stringData.constBegin(), stringData.constBegin() + qMin(10, stringData.size()), data.date);
        data.date[qMin(11, stringData.size())] = '\0';

        return data;
    }

    static Cars fromCarData(CarData &data) {
        Cars car;
        // Модель автомобиля
        car.Model = QString::fromUtf8(data.Model);
        // ID
        car.id = data.id;
        // Количество
        car.quantity = data.quantity;
        // Цен
        car.price = data.price;
        // Объе
        car.volume = data.volume;
        // Вместимость
        car.Capacity = data.Capacity;
        // Грузоподъемность
        car.Carrying = data.Carrying;
        // Ускорение
        car.Acceleration = data.Acceleration;
        // Максимальная скорость
        car.MaxSpeed = data.MaxSpeed;
        // Климат-контроль
        car.Climat = data.Climat;
        // Пассажирский
        car.Passenger = data.Passenger;
        // Грузовик
        car.Truck = data.Truck;
        // Прицеп
        car.Trailer = data.Trailer;
        // Автобус
        car.Bus = data.Bus;
        // Дата
        car.date = QDate::fromString(QString::fromUtf8(data.date), "dd.MM.yyyy");
        return car;
    }


    bool operator<(Cars tmp)
    {
        if(Passenger>tmp.Passenger)
        {
            return true;

        }
        else
        {
         if(Passenger == tmp.Passenger)
         {
             if(this->Truck > tmp.Truck)
             {
                 return true;
             }
             else
             {
                 if(Truck == tmp.Truck)
                 {
                     if(Bus<tmp.Bus)
                     {
                         return true;
                     }
                     else
                     {
                         if(Bus == tmp.Bus)
                         {
                             if(Trailer>tmp.Trailer)
                             {
                                 return true;
                             }
                             else
                             {
                                 if(Trailer == tmp.Trailer)
                                 {
                                     if(volume > tmp.volume)
                                     {
                                         return true;
                                     }
                                     else
                                     {
                                         if(volume == tmp.volume)
                                         {
                                             if(Capacity > tmp.Capacity)
                                             {
                                                 return true;
                                             }
                                             else
                                             {
                                                 if(Capacity == tmp.Capacity)
                                                 {
                                                     if(price>tmp.price)
                                                     {
                                                         return true;
                                                     }
                                                     else{
                                                         if(price == tmp.price)
                                                         {
                                                             if(Model > tmp.Model)
                                                         {
                                                            return true;
                                                         }
                                                         }
                                                      return false;
                                                     }
                                                 }
                                             }
                                              return false;
                                         }
                                     }
                                      return false;
                                 }
                             }
                              return false;
                         }
                     }
                      return false;
                 }
             }
              return false;
         }
          return false;
        }

    }

private:

};

#endif // SAVEDATA_H
